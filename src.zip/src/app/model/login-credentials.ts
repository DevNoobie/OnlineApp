export class LoginCredentials {

    loginId: string = "";
    password: string = "";
    isUserAdmin: boolean = false;

}
