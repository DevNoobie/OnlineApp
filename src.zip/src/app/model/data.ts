export class Data {

    token: string = "zcx";
    errorMessage: string = "";
    
}
