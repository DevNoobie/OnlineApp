export class Product {

    productName: string = "";
    productDescription: string = "";
    price: number = 0;
    features: string = "";
    productStatus: string = "";
    noOfOrders: number = 0;
    noOfProducts: number = 0;

}
