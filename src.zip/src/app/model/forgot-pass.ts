export class ForgotPass {
    LoginId: string = "";
    isUserAdmin: boolean = false;
}
