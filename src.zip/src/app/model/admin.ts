export class Admin {
    email: string = "";
    fullName: string = "";
    password: string = "";
}
